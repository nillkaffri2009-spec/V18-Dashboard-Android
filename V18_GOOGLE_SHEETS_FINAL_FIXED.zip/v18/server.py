from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from pathlib import Path
import json, threading, time, os, socket, urllib.request, urllib.error, urllib.parse

ROOT = Path(__file__).resolve().parent
PREFERRED_IP = ''
STATE = ROOT / 'state.json'
DEFAULT = {'month':'Iyun','day':10,'page':1,'code':'21120','detail':None,'ts':0,'version':0,'source':'admin'}
PROXY_CONFIG = ROOT / 'google_proxy.json'
LIVE_CACHE = ROOT / 'live_cache.json'
SPREADSHEET_ID = '1IWyUdorge58MbvpNlB5Z08Rawm8AdoeHinxgjiFktF4'
SHEETS_EXPORT_URL = f'https://docs.google.com/spreadsheets/d/{SPREADSHEET_ID}/export?format=xlsx'
SHEETS_EDIT_URL = f'https://docs.google.com/spreadsheets/d/{SPREADSHEET_ID}/edit'
SHEETS_GVIZ_URL = f'https://docs.google.com/spreadsheets/d/{SPREADSHEET_ID}/gviz/tq'
PRIMARY_GID = '1701842361'
lock = threading.RLock()

def load_state():
    try:
        return json.loads(STATE.read_text(encoding='utf-8'))
    except Exception:
        return DEFAULT.copy()

def save_state(data):
    tmp = STATE.with_suffix('.tmp')
    tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding='utf-8')
    os.replace(tmp, STATE)

if not STATE.exists(): save_state(DEFAULT)

def get_lan_ip():
    """Return the current non-loopback LAN IPv4 address."""
    try:
        ips=[]
        for info in socket.getaddrinfo(socket.gethostname(), None, socket.AF_INET):
            ip=info[4][0]
            if ip and not ip.startswith("127.") and not ip.startswith("169.254.") and ip not in ips:
                ips.append(ip)
        if PREFERRED_IP in ips:
            return PREFERRED_IP
        if ips:
            return ips[0]
    except Exception:
        pass
    try:
        sock=socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        sock.settimeout(0.5)
        sock.connect(("192.0.2.1",1))
        ip=sock.getsockname()[0]
        sock.close()
        if ip and not ip.startswith("127.") and not ip.startswith("169.254."):
            return ip
    except Exception:
        pass
    return '127.0.0.1'

def load_proxy_config():
    try:
        return json.loads(PROXY_CONFIG.read_text(encoding='utf-8'))
    except Exception:
        return {'url':'','key':''}

MONTHS = ['Yanvar','Fevral','Mart','Aprel','May','Iyun','Iyul','Avgust','Sentabr','Oktabr','Noyabr','Dekabr']
MONTH_BY_CODE = {f'2026{i:02d}': m for i,m in enumerate(MONTHS,1)}

def _num(v):
    try:
        if v in (None, ''): return 0.0
        return float(v)
    except Exception:
        return 0.0

def _month_from_marker(v):
    """Normalize Google Sheets month marker values such as 202608, 202608.0, '202608'."""
    if v is None:
        return None
    text=str(v).strip()
    if text.endswith('.0'):
        text=text[:-2]
    text=text.replace(' ', '')
    if text in MONTH_BY_CODE:
        return MONTH_BY_CODE[text]
    # Some exports can stringify numeric cells with decimals/scientific notation.
    try:
        n=int(float(text))
        code=str(n)
        return MONTH_BY_CODE.get(code)
    except Exception:
        return None

def _is_header_row(row):
    vals=[str(x or '').strip().lower().replace('‘',"'").replace('’',"'") for x in row[:8]]
    joined=' | '.join(vals)
    return ('bo\'lim kodi' in joined or 'bo‘lim kodi' in joined) and ('xodim' in joined or 'xodim' in joined)

def _sheet_code_from_name(name):
    import re
    m=re.search(r'(?<!\d)(\d{5})(?!\d)', str(name or ''))
    return m.group(1) if m else ''

def normalize_google_payload(payload):
    # Convert Google Sheets 2-D values into the exact data.json contract used
    # by the existing Dashboard UI. This parser deliberately tolerates both
    # XLSX and CSV/GViz exports, including numeric 202608.0 month markers.
    if not isinstance(payload, dict) or not payload.get('ok'):
        raise RuntimeError(str((payload or {}).get('error') or 'Google Sheets javobi noto\'g\'ri'))
    sheets = payload.get('sheets') or []
    records=[]
    source_info=[]
    dashboard_summary=[]
    for sh in sheets:
        name=str(sh.get('name') or '')
        rows=sh.get('values') or []
        if name.strip().lower() == 'dashboard':
            # Dashboard tab: B=code, C=name, D=latest month count.
            for row in rows:
                if len(row)>=4:
                    code=str(row[1] or '').strip()
                    nm=str(row[2] or '').strip()
                    if code.isdigit() and nm:
                        dashboard_summary.append({'code':code,'name':nm,'count':_num(row[3])})
            continue
        current_month=None
        data_count=0
        sheet_code=_sheet_code_from_name(name)
        for row in rows:
            marker=_month_from_marker(row[2] if len(row)>2 else None)
            if marker:
                current_month=marker
                continue
            if _is_header_row(row):
                continue
            if current_month is None or len(row)<15:
                continue
            code=str(row[2] if len(row)>2 and row[2] is not None else '').strip()
            tab=str(row[3] if len(row)>3 and row[3] is not None else '').strip()
            emp=str(row[4] if len(row)>4 and row[4] is not None else '').strip()
            if not code or not emp or not tab:
                continue
            # Employee rows have C=department code, D=tab no, E=name.
            day=[row[i] if i<len(row) else None for i in range(14,45)]
            records.append({
                'm':current_month,'d':code,'e':emp,'tab':tab,
                's':str(row[5] if len(row)>5 and row[5] is not None else '').strip(),
                'g':_num(row[6] if len(row)>6 else None),
                'j':_num(row[9] if len(row)>9 else None),
                'x':_num(row[12] if len(row)>12 else None),
                'day':day
            })
            data_count+=1
        if data_count:
            source_info.append({'code':sheet_code or str(records[-1]['d']),
                                'name':name.split(' (')[0].strip(),'sheet':name})

    # Prefer the dedicated Dashboard tab's department list because it is the
    # authoritative display order/name list. If absent, derive it from data tabs.
    summary=[]; seen=set()
    for x in dashboard_summary:
        if x['code'] not in seen:
            summary.append(x); seen.add(x['code'])
    # Derive any departments not present in Dashboard summary.
    for x in source_info:
        if x['code'] and x['code'] not in seen:
            rr=[r for r in records if r['d']==x['code']]
            if rr:
                latest=max(MONTHS.index(r['m']) for r in rr)
                summary.append({'code':x['code'],'name':x['name'],
                                'count':sum(1 for r in rr if MONTHS.index(r['m'])==latest)})
                seen.add(x['code'])

    # Always calculate counts from the newest month actually present in records.
    order={m:i for i,m in enumerate(MONTHS)}
    for x in summary:
        rr=[r for r in records if str(r['d'])==str(x['code'])]
        if rr:
            latest=max(order.get(r['m'],-1) for r in rr)
            x['count']=sum(1 for r in rr if order.get(r['m'],-1)==latest)
        else:
            x['count']=0
    present_months=sorted({r['m'] for r in records}, key=lambda m: order.get(m,99))
    return {'summary':summary,'records':records,'sourceInfo':source_info,'months':MONTHS,
            'meta':{'source':'Google Sheets','updatedAt':int(time.time()*1000),
                    'monthsPresent':present_months}}

def _json_safe(v):
    # openpyxl can return datetime/date/time objects; make them JSON-safe.
    import datetime as _dt
    if isinstance(v, (_dt.datetime, _dt.date, _dt.time)):
        return v.isoformat()
    return v

def _read_xlsx_bytes(blob):
    """Small dependency-free XLSX reader for the plain tabular sheets used here."""
    import zipfile, io, xml.etree.ElementTree as ET
    from xml.etree.ElementTree import QName
    NS_MAIN='http://schemas.openxmlformats.org/spreadsheetml/2006/main'
    NS_REL='http://schemas.openxmlformats.org/officeDocument/2006/relationships'
    PKG_REL='http://schemas.openxmlformats.org/package/2006/relationships'
    def tag(ns, name): return '{%s}%s' % (ns,name)
    with zipfile.ZipFile(io.BytesIO(blob)) as z:
        names=set(z.namelist())
        shared=[]
        if 'xl/sharedStrings.xml' in names:
            root=ET.fromstring(z.read('xl/sharedStrings.xml'))
            for si in root.findall(tag(NS_MAIN,'si')):
                shared.append(''.join(t.text or '' for t in si.iter(tag(NS_MAIN,'t'))))
        wb=ET.fromstring(z.read('xl/workbook.xml'))
        rels=ET.fromstring(z.read('xl/_rels/workbook.xml.rels'))
        relmap={r.attrib.get('Id'):r.attrib.get('Target','') for r in rels}
        sheets=[]
        for sh in wb.find(tag(NS_MAIN,'sheets')):
            name=sh.attrib.get('name','')
            rid=sh.attrib.get('{%s}id'%NS_REL)
            target=relmap.get(rid,'')
            if target.startswith('/'):
                path=target.lstrip('/')
            elif target.startswith('xl/'):
                path=target
            else:
                path='xl/'+target
            # Normalize accidental xl/../ paths.
            path=str(Path(path).as_posix())
            if path not in names and ('xl/'+target) in names: path='xl/'+target
            if path not in names: continue
            root=ET.fromstring(z.read(path))
            data=root.find(tag(NS_MAIN,'sheetData'))
            rows=[]
            max_col=0
            raw=[]
            for rr in data or []:
                cells={}
                for c in rr.findall(tag(NS_MAIN,'c')):
                    ref=c.attrib.get('r','')
                    letters=''.join(ch for ch in ref if ch.isalpha()).upper()
                    if not letters: continue
                    col=0
                    for ch in letters: col=col*26+(ord(ch)-64)
                    max_col=max(max_col,col)
                    typ=c.attrib.get('t')
                    v=c.find(tag(NS_MAIN,'v'))
                    val=None
                    if typ=='s' and v is not None and v.text is not None:
                        try: val=shared[int(v.text)]
                        except Exception: val=v.text
                    elif typ=='inlineStr':
                        val=''.join(t.text or '' for t in c.iter(tag(NS_MAIN,'t')))
                    elif v is not None:
                        val=v.text
                    else:
                        isel=c.find(tag(NS_MAIN,'is'))
                        if isel is not None: val=''.join(t.text or '' for t in isel.iter(tag(NS_MAIN,'t')))
                    # Keep numeric-looking values numeric enough for the month parser.
                    if isinstance(val,str):
                        vv=val.strip()
                        if vv and vv.replace('.','',1).isdigit() and vv.count('.')<=1:
                            try: val=float(vv) if '.' in vv else int(vv)
                            except Exception: pass
                    cells[col-1]=val
                raw.append(cells)
            for cells in raw:
                row=[None]*max_col
                for idx,val in cells.items(): row[idx]=val
                rows.append(row)
            sheets.append({'name':name,'values':rows})
        return sheets

def fetch_google_xlsx():
    """Fetch the complete public Google workbook; no Apps Script is required."""
    url=SHEETS_EXPORT_URL + '&_v18=' + str(int(time.time()*1000))
    req=urllib.request.Request(url,headers={
        'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/151 Safari/537.36',
        'Accept':'*/*'
    })
    with urllib.request.urlopen(req,timeout=30) as r:
        blob=r.read()
    if len(blob) < 4096 or not blob.startswith(b'PK'):
        preview=blob[:120].decode('utf-8','ignore') if blob else ''
        raise RuntimeError('Google Sheets XLSX exporti olinmadi: '+preview)
    sheets=_read_xlsx_bytes(blob)
    if not sheets:
        raise RuntimeError('Google Sheets XLSX ichida list topilmadi')
    data=normalize_google_payload({'ok':True,'sheets':sheets})
    data['meta']['source']='Google Sheets LIVE (direct XLSX)'
    data['meta']['spreadsheetId']=SPREADSHEET_ID
    data['meta']['fetchedAt']=int(time.time()*1000)
    return data

def _discover_sheet_gids():
    """Best-effort discovery of sheet tabs for public/link-viewable spreadsheets."""
    url=SHEETS_EDIT_URL + '?_v18=' + str(int(time.time()*1000))
    req=urllib.request.Request(url,headers={'User-Agent':'Mozilla/5.0'})
    with urllib.request.urlopen(req,timeout=20) as r:
        html=r.read().decode('utf-8','ignore')
    import re
    gids=[]
    for pat in [r'"sheetId"\s*:\s*"?(\d+)"?', r'"gid"\s*:\s*"?(\d+)"?']:
        for g in re.findall(pat,html):
            if g not in gids: gids.append(g)
    return gids

def _csv_rows(text):
    import csv, io
    return [list(r) for r in csv.reader(io.StringIO(text))]

def fetch_google_gviz():
    """Read the known live Dashboard_BAZA tab directly as CSV."""
    # Do not depend on scraping the Google Sheets edit page. The user has
    # already provided the live tab gid, and the CSV endpoint is the most
    # reliable public read path for a link-viewable sheet.
    gids=[PRIMARY_GID]
    if not gids:
        raise RuntimeError('Google Sheets listlari aniqlanmadi')
    sheets=[]
    for gid in gids:
        url=SHEETS_GVIZ_URL + '?gid=' + urllib.parse.quote(str(gid)) + '&tqx=out:csv&_v18=' + str(int(time.time()*1000))
        req=urllib.request.Request(url,headers={'User-Agent':'Mozilla/5.0','Accept':'text/csv'})
        with urllib.request.urlopen(req,timeout=20) as r:
            text=r.read().decode('utf-8','ignore')
        rows=_csv_rows(text)
        if rows:
            sheets.append({'name':'gid_'+str(gid),'values':rows})
    payload={'ok':True,'sheets':sheets}
    data=normalize_google_payload(payload)
    data['meta']['source']='Google Sheets LIVE (GViz CSV)'
    data['meta']['spreadsheetId']=SPREADSHEET_ID
    data['meta']['fetchedAt']=int(time.time()*1000)
    return data

def _load_local_cache():
    try:
        data=json.loads(LIVE_CACHE.read_text(encoding='utf-8'))
        if is_usable_normalized(data):
            data.setdefault('meta',{})['source']='Google Sheets LIVE CACHE'
            return data
    except Exception:
        pass
    return None

def is_usable_normalized(data):
    return isinstance(data,dict) and isinstance(data.get('records'),list) and len(data.get('records',[]))>0 and isinstance(data.get('months'),list)

def _load_snapshot():
    try:
        data=json.loads((ROOT/'data.json').read_text(encoding='utf-8'))
        if is_usable_normalized(data):
            data.setdefault('meta',{})['source']='LOCAL SNAPSHOT'
            return data
    except Exception:
        pass
    return None

def fetch_google_proxy():
    """Fetch the complete public workbook first; single-tab GViz is only a fallback."""
    errors=[]
    try:
        data=fetch_google_xlsx()
        if data.get('records') and len(data.get('summary') or []) >= 2:
            try:
                LIVE_CACHE.write_text(json.dumps(data,ensure_ascii=False),encoding='utf-8')
            except Exception:
                pass
            return data
        errors.append('xlsx: workbook returned incomplete data')
    except Exception as e:
        errors.append('xlsx: '+str(e))
    try:
        data=fetch_google_gviz()
        # Do not silently treat the first department tab as the whole workbook.
        # A one-tab response is useful only when the Dashboard summary is also present.
        if data.get('records') and len(data.get('summary') or []) >= 2:
            try:
                LIVE_CACHE.write_text(json.dumps(data,ensure_ascii=False),encoding='utf-8')
            except Exception:
                pass
            return data
        errors.append("gviz: faqat bitta list/bo'lim qaytdi")
    except Exception as e:
        errors.append('gviz: '+str(e))

    cfg=load_proxy_config(); url=str(cfg.get('url') or '').strip(); key=str(cfg.get('key') or '').strip()
    if url:
        sep='&' if '?' in url else '?'
        target=url + (sep + urllib.parse.urlencode({'key':key}) if key else '')
        req=urllib.request.Request(target,headers={'User-Agent':'MamuriyatLiveMonitor/18'})
        try:
            with urllib.request.urlopen(req,timeout=20) as r:
                data=normalize_google_payload(json.loads(r.read().decode('utf-8')))
            data['meta']['source']='Google Sheets LIVE (Apps Script)'
            data['meta']['fetchedAt']=int(time.time()*1000)
            try:
                LIVE_CACHE.write_text(json.dumps(data,ensure_ascii=False),encoding='utf-8')
            except Exception:
                pass
            return data
        except Exception as e:
            errors.append('Apps Script: '+str(e))

    cached=_load_local_cache()
    if cached:
        cached['meta']['warning']='Live Google Sheets vaqtincha ulanmayapti; oxirgi muvaffaqiyatli nusxa ishlatilmoqda.'
        return cached
    snapshot=_load_snapshot()
    if snapshot:
        snapshot['meta']['warning']='Google Sheets ulanmagan; ZIP ichidagi zaxira nusxa ishlatilmoqda.'
        return snapshot
    raise RuntimeError('Google Sheets ulanib bo‘lmadi: '+' | '.join(errors))

class Handler(SimpleHTTPRequestHandler):
    def end_headers(self):
        self.send_header('Cache-Control','no-store, no-cache, must-revalidate, max-age=0')
        self.send_header('Pragma','no-cache')
        self.send_header('Expires','0')
        super().end_headers()

    protocol_version = 'HTTP/1.1'
    def __init__(self,*a,**kw): super().__init__(*a,directory=str(ROOT),**kw)
    def log_message(self,fmt,*args): pass
    def _headers(self,code=200,ctype='application/json',length=None):
        self.send_response(code)
        self.send_header('Content-Type',ctype+'; charset=utf-8')
        self.send_header('Cache-Control','no-store, no-cache, must-revalidate, max-age=0')
        self.send_header('Pragma','no-cache'); self.send_header('Expires','0')
        self.send_header('Access-Control-Allow-Origin','*')
        self.send_header('Access-Control-Allow-Methods','GET,POST,OPTIONS')
        self.send_header('Access-Control-Allow-Headers','Content-Type')
        if length is not None: self.send_header('Content-Length',str(length))
        self.end_headers()
    def _json(self,obj,code=200):
        raw=json.dumps(obj,ensure_ascii=False).encode('utf-8')
        self._headers(code,'application/json',len(raw)); self.wfile.write(raw)
    def do_OPTIONS(self):
        self.send_response(204); self.send_header('Access-Control-Allow-Origin','*')
        self.send_header('Access-Control-Allow-Methods','GET,POST,OPTIONS')
        self.send_header('Access-Control-Allow-Headers','Content-Type'); self.send_header('Content-Length','0'); self.end_headers()
    def do_GET(self):
        route=self.path.split('?',1)[0]
        if route in ('/monitor','/monitor/','/monitor.html','/phone','/phone/','/tv','/tv/','/tv.html'):
            # MONITOR/PHONE must load the monitor document, never admin.html.
            # The monitor document detects monitor mode from both the query and path.
            self.path='/monitor.html'
            super().do_GET()
            return
        if route in ('/admin','/admin/'):
            self.path='/admin.html'
            super().do_GET()
            return
        if route in ('/','/index.html'):
            self.path='/admin.html'
            super().do_GET()
            return
        if route=='/api/health': self._json({'ok':True,'server_time':int(time.time()*1000),'ip':get_lan_ip(),'port':5000}); return
        if route=='/api/state':
            with lock: data=load_state()
            self._json(data); return
        if route=='/api/network':
            ip=get_lan_ip()
            self._json({'ok':True,'ip':ip,'admin_url':f'http://{ip}:5000/admin.html','monitor_url':f'http://{ip}:5000/monitor.html?mode=monitor'})
            return
        if route=='/api/google-data':
            try: self._json(fetch_google_proxy());
            except Exception as e: self._json({'ok':False,'error':str(e)},502)
            return
        super().do_GET()
    def do_POST(self):
        if self.path.split('?',1)[0]!='/api/state': self.send_error(404); return
        try:
            n=int(self.headers.get('Content-Length','0')); incoming=json.loads(self.rfile.read(n) or b'{}')
            for k in ('month','day','page','code','detail','ts'):
                if k not in incoming: raise ValueError('Missing field: '+k)
            incoming['month']=str(incoming['month']); incoming['day']=int(incoming['day'])
            incoming['page']=max(1,min(3,int(incoming['page']))); incoming['code']=str(incoming['code']); incoming['ts']=int(incoming['ts'])
            incoming['source']='admin'
            now=int(time.time()*1000)
            with lock:
                current=load_state(); current_ts=int(current.get('ts') or 0)
                # Recover automatically from a corrupted/future timestamp in state.json.
                # A previous build could contain a sentinel timestamp (e.g. 9999999999999),
                # which incorrectly caused every valid ADMIN update to be rejected as old.
                current_is_future_corrupt = current_ts > (now + 86400000)
                if (not current_is_future_corrupt) and incoming['ts'] < current_ts:
                    saved=current
                else:
                    incoming['version']=max(now,incoming['ts']); save_state(incoming); saved=incoming
            self._json({'ok':True,'state':saved})
        except Exception as e: self._json({'ok':False,'error':str(e)},400)

if __name__=='__main__':
    host,port='0.0.0.0',5000
    lan_ip=get_lan_ip()
    print('='*64); print("MA'MURIYAT BO'LIMI — LIVE MONITOR SERVER V18"); print('='*64)
    print(f'ADMIN:   http://{lan_ip}:{port}/admin.html')
    print(f'ADMIN local: http://127.0.0.1:{port}/admin.html')
    print(f'LAN IP:  {lan_ip}')
    print(f'MONITOR: http://{lan_ip}:{port}/monitor.html?mode=monitor')
    print(f'PHONE:   http://{lan_ip}:{port}/monitor.html?mode=monitor')
    print('ADMIN -> server state -> MONITOR: 0.5 soniyalik avtomatik sinxronizatsiya.')
    print('Google private-sheet proxy: /api/google-data (ixtiyoriy)')
    print('Faqat ADMIN boshqaradi; MONITOR faqat aks ettiradi.')
    print('CTRL+C — serverni to‘xtatish'); print('='*64)
    ThreadingHTTPServer((host,port),Handler).serve_forever()
