@echo off
cd /d "%~dp0"
echo MAMURIYAT telefon ulanish tekshiruvi
curl -fsS --max-time 5 http://127.0.0.1:5000/api/health
if errorlevel 1 echo SERVER: ISHLAMAYAPTI
if not errorlevel 1 echo SERVER: ISHLAYAPTI
if exist PHONE_PUBLIC_URL.txt (
  echo.
  echo PUBLIC URL:
  type PHONE_PUBLIC_URL.txt
)
echo.
echo Administrator huquqi bu tekshiruv uchun kerak emas.
pause
