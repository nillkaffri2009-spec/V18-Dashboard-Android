@echo off
start "GOOGLE SHEETS" "https://docs.google.com/spreadsheets/d/1b8ERtJ-XFPTiIx09xGKVpCmupOZGeR9Qfna50M7cZpI/edit?usp=drivesdk"
