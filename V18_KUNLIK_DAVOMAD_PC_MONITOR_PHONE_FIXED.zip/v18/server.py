from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from pathlib import Path
import json, threading, time, os, socket, urllib.request, urllib.error, urllib.parse, subprocess, shutil, re, csv, io

ROOT = Path(__file__).resolve().parent
PREFERRED_IP = ''
STATE = ROOT / 'state.json'
DEFAULT = {'month':'Iyun','day':10,'page':1,'code':'21120','detail':None,'ts':0,'version':0,'source':'admin'}
PROXY_CONFIG = ROOT / 'google_proxy.json'
LIVE_CACHE = ROOT / 'live_cache.json'
SPREADSHEET_ID = '1IWyUdorge58MbvpNlB5Z08Rawm8AdoeHinxgjiFktF4'
SHEETS_EXPORT_URL = f'https://docs.google.com/spreadsheets/d/{SPREADSHEET_ID}/export?format=xlsx'
SHEETS_EDIT_URL = f'https://docs.google.com/spreadsheets/d/{SPREADSHEET_ID}/edit'
SHEETS_GVIZ_URL = f'https://docs.google.com/spreadsheets/d/{SPREADSHEET_ID}/gviz/tq'
PRIMARY_GID = '1701842361'
lock = threading.RLock()

def load_state():
    try:
        return json.loads(STATE.read_text(encoding='utf-8'))
    except Exception:
        return DEFAULT.copy()

def save_state(data):
    tmp = STATE.with_suffix('.tmp')
    tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding='utf-8')
    os.replace(tmp, STATE)

if not STATE.exists(): save_state(DEFAULT)

def get_lan_ip():
    """Return the current non-loopback LAN IPv4 address."""
    try:
        ips=[]
        for info in socket.getaddrinfo(socket.gethostname(), None, socket.AF_INET):
            ip=info[4][0]
            if ip and not ip.startswith("127.") and not ip.startswith("169.254.") and ip not in ips:
                ips.append(ip)
        if PREFERRED_IP in ips:
            return PREFERRED_IP
        if ips:
            return ips[0]
    except Exception:
        pass
    try:
        sock=socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        sock.settimeout(0.5)
        sock.connect(("192.0.2.1",1))
        ip=sock.getsockname()[0]
        sock.close()
        if ip and not ip.startswith("127.") and not ip.startswith("169.254."):
            return ip
    except Exception:
        pass
    return '127.0.0.1'

def load_proxy_config():
    try:
        return json.loads(PROXY_CONFIG.read_text(encoding='utf-8'))
    except Exception:
        return {'url':'','key':''}

MONTHS = ['Yanvar','Fevral','Mart','Aprel','May','Iyun','Iyul','Avgust','Sentabr','Oktabr','Noyabr','Dekabr']
MONTH_BY_CODE = {f'2026{i:02d}': m for i,m in enumerate(MONTHS,1)}

def _num(v):
    try:
        if v in (None, ''): return 0.0
        return float(v)
    except Exception:
        return 0.0

def _month_from_value(v):
    """Recognize 202601..202612 even when Sheets exports it as 202608, 202608.0, etc."""
    if v is None: return None
    txt=str(v).strip()
    m=re.fullmatch(r'2026(?:0[1-9]|1[0-2])(?:\.0+)?', txt)
    if not m: return None
    code=txt.split('.')[0]
    return MONTH_BY_CODE.get(code)

def _clean_cell(v):
    if v is None: return ''
    return str(v).strip()

def normalize_google_payload(payload):
    # Convert Google Sheets rows into the exact data.json contract used by V18.
    if not isinstance(payload, dict) or not payload.get('ok'):
        raise RuntimeError(str((payload or {}).get('error') or "Google Sheets javobi noto'g'ri"))
    sheets = payload.get('sheets') or []
    records=[]
    source_info=[]
    dashboard_summary=[]
    order={m:i for i,m in enumerate(MONTHS)}

    for sh in sheets:
        name=str(sh.get('name') or '')
        rows=sh.get('values') or []
        # A sheet may contain a Dashboard summary, but the detailed tab is the
        # authoritative source for the live daily attendance records.
        if name.strip().lower() == 'dashboard':
            for row in rows:
                vals=[_clean_cell(x) for x in row]
                for i in range(max(0,len(vals)-2)):
                    if re.fullmatch(r'\d+', vals[i]) and vals[i+1] and i+2 < len(vals):
                        try:
                            dashboard_summary.append({'code':vals[i],'name':vals[i+1],'count':_num(vals[i+2])})
                        except Exception:
                            pass
            continue

        current_month=None
        for row in rows:
            vals=[_clean_cell(x) for x in row]
            # Month marker can appear anywhere in a row; do not assume column C.
            found_month=next((mm for x in vals if (mm := _month_from_value(x))), None)
            if found_month:
                current_month=found_month
                continue
            if current_month is None:
                continue

            # The established sheet layout is C=department, D=tab, E=name,
            # F=shift, G=fund, J=fund work hours, M=sverh, O:AS=daily statuses.
            # Keep this mapping, but tolerate shorter CSV rows and stray blanks.
            if len(vals) < 5:
                continue
            code=vals[2] if len(vals)>2 else ''
            tab=vals[3] if len(vals)>3 else ''
            emp=vals[4] if len(vals)>4 else ''
            # Ignore section headers and blank rows.
            if not code or not emp or not tab:
                continue
            if code.lower() in ("bo'lim ko'di", 'bo‘lim kodi', 'bo\'lim kodi', 'bo‘lim ko\'di'):
                continue
            # Department codes in this source are numeric (e.g. 21010, 21120).
            if not re.fullmatch(r'\d+', code):
                continue
            # Tab numbers are also numeric in the source; tolerate leading zeros.
            if not re.fullmatch(r'[A-Za-z0-9_-]+', tab):
                continue
            day=[row[i] if i<len(row) else '' for i in range(14,45)]
            records.append({
                'm':current_month,'d':code,'e':emp,'tab':tab,
                's':vals[5] if len(vals)>5 else '',
                'g':_num(vals[6] if len(vals)>6 else None),
                'j':_num(vals[9] if len(vals)>9 else None),
                'x':_num(vals[12] if len(vals)>12 else None),
                'day':day
            })

    # Build the department summary from the actual detailed records. This is
    # more reliable than an auxiliary summary that may lag behind the current month.
    by_dept={}
    for r in records:
        by_dept.setdefault(r['d'], []).append(r)
    summary=[]
    # Preserve the familiar department order from the existing snapshot when possible.
    snap_names={}
    try:
        snap=json.loads((ROOT/'data.json').read_text(encoding='utf-8'))
        for x in snap.get('summary',[]): snap_names[str(x.get('code'))]=str(x.get('name') or '')
    except Exception:
        pass
    for code,rr in by_dept.items():
        latest=max(order.get(r['m'],-1) for r in rr)
        summary.append({'code':code,'name':snap_names.get(code,code),'count':sum(1 for r in rr if order.get(r['m'],-1)==latest)})
    # If the source contains names in a dashboard summary, use them only as labels.
    for x in dashboard_summary:
        code=str(x['code'])
        if code in by_dept:
            for y in summary:
                if y['code']==code and x.get('name'):
                    y['name']=str(x['name'])
    summary.sort(key=lambda x: (int(x['code']) if x['code'].isdigit() else 10**9, x['code']))
    present_months=sorted({r['m'] for r in records}, key=lambda m: order.get(m,99))
    if not records:
        raise RuntimeError('Google Sheetsdan xodim yozuvlari topilmadi')
    return {'summary':summary,'records':records,'sourceInfo':[{'sheet':str(sh.get('name') or '')} for sh in sheets],
            'months':MONTHS,
            'meta':{'source':'Google Sheets','updatedAt':int(time.time()*1000),'monthsPresent':present_months}}

def _json_safe(v):
    # openpyxl can return datetime/date/time objects; make them JSON-safe.
    import datetime as _dt
    if isinstance(v, (_dt.datetime, _dt.date, _dt.time)):
        return v.isoformat()
    return v

def _fetch_remote(url, timeout=30, accept='*/*'):
    """Use Windows curl/PowerShell first, then urllib. This avoids Python TLS/proxy
    differences on PCs where Chrome can reach Google but urllib cannot."""
    curl=shutil.which('curl.exe') or shutil.which('curl')
    if curl:
        try:
            cp=subprocess.run([curl,'-L','--fail','--silent','--show-error','--max-time',str(timeout),
                               '-A','Mozilla/5.0','-H',f'Accept: {accept}',url],
                              capture_output=True,timeout=timeout+5)
            if cp.returncode==0 and cp.stdout:
                return cp.stdout
        except Exception:
            pass
    # Windows PowerShell fallback.
    ps=shutil.which('powershell.exe') or shutil.which('powershell')
    if ps:
        try:
            cmd=f"$ProgressPreference='SilentlyContinue'; $r=Invoke-WebRequest -UseBasicParsing -Uri '{url.replace(chr(39), chr(39)+chr(39))}' -Headers @{{'User-Agent'='Mozilla/5.0'}} -TimeoutSec {timeout}; [Console]::OpenStandardOutput().Write($r.Content,0,$r.Content.Length)"
            cp=subprocess.run([ps,'-NoProfile','-ExecutionPolicy','Bypass','-Command',cmd],capture_output=True,timeout=timeout+8)
            if cp.returncode==0 and cp.stdout:
                return cp.stdout
        except Exception:
            pass
    req=urllib.request.Request(url,headers={'User-Agent':'Mozilla/5.0','Accept':accept})
    with urllib.request.urlopen(req,timeout=timeout) as r:
        return r.read()

def fetch_google_csv():
    """Read the exact live Dashboard_BAZA tab as CSV. No Apps Script is needed."""
    url=(f'https://docs.google.com/spreadsheets/d/{SPREADSHEET_ID}/export'
         f'?format=csv&gid={urllib.parse.quote(PRIMARY_GID)}&_v18={int(time.time()*1000)}')
    blob=_fetch_remote(url,timeout=30,accept='text/csv')
    if not blob:
        raise RuntimeError('Google Sheets CSV javobi bo\'sh')
    text=blob.decode('utf-8-sig','replace')
    rows=[list(r) for r in csv.reader(io.StringIO(text))]
    if len(rows)<2:
        raise RuntimeError('Google Sheets CSVda yetarli qator yo\'q')
    data=normalize_google_payload({'ok':True,'sheets':[{'name':'Dashboard_BAZA Кунлик давомад','values':rows}]})
    data['meta']['source']='Google Sheets LIVE (CSV export)'
    data['meta']['spreadsheetId']=SPREADSHEET_ID
    data['meta']['fetchedAt']=int(time.time()*1000)
    return data

def fetch_google_xlsx():
    """Fetch the public Google Sheet directly; no Apps Script deployment is required."""
    url = SHEETS_EXPORT_URL + '&_v18=' + str(int(time.time()*1000))
    req=urllib.request.Request(
        url,
        headers={'User-Agent':'MamuriyatLiveMonitor/18','Accept':'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'}
    )
    blob=_fetch_remote(url,timeout=30,accept='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')
    if len(blob) < 4096 or not blob.startswith(b'PK'):
        raise RuntimeError('Google Sheets XLSX exporti olinmadi (jadval ommaga ochiq bo‘lishi kerak)')
    try:
        from io import BytesIO
        from openpyxl import load_workbook
        wb=load_workbook(BytesIO(blob),read_only=True,data_only=True)
    except Exception as e:
        raise RuntimeError('Google Sheets XLSX o‘qilmadi: '+str(e))
    sheets=[]
    for ws in wb.worksheets:
        values=[]
        for row in ws.iter_rows(values_only=True):
            values.append([_json_safe(v) for v in row])
        sheets.append({'name':ws.title,'values':values})
    wb.close()
    payload={'ok':True,'sheets':sheets}
    data=normalize_google_payload(payload)
    data['meta']['source']='Google Sheets LIVE (direct XLSX)'
    data['meta']['spreadsheetId']=SPREADSHEET_ID
    data['meta']['fetchedAt']=int(time.time()*1000)
    return data

def _discover_sheet_gids():
    """Best-effort discovery of sheet tabs for public/link-viewable spreadsheets."""
    url=SHEETS_EDIT_URL + '?_v18=' + str(int(time.time()*1000))
    req=urllib.request.Request(url,headers={'User-Agent':'Mozilla/5.0'})
    with urllib.request.urlopen(req,timeout=20) as r:
        html=r.read().decode('utf-8','ignore')
    import re
    gids=[]
    for pat in [r'"sheetId"\s*:\s*"?(\d+)"?', r'"gid"\s*:\s*"?(\d+)"?']:
        for g in re.findall(pat,html):
            if g not in gids: gids.append(g)
    return gids

def _csv_rows(text):
    import csv, io
    return [list(r) for r in csv.reader(io.StringIO(text))]

def fetch_google_gviz():
    """Read the known live Dashboard_BAZA tab directly as CSV."""
    # Do not depend on scraping the Google Sheets edit page. The user has
    # already provided the live tab gid, and the CSV endpoint is the most
    # reliable public read path for a link-viewable sheet.
    gids=[PRIMARY_GID]
    if not gids:
        raise RuntimeError('Google Sheets listlari aniqlanmadi')
    sheets=[]
    for gid in gids:
        url=SHEETS_GVIZ_URL + '?gid=' + urllib.parse.quote(str(gid)) + '&tqx=out:csv&_v18=' + str(int(time.time()*1000))
        req=urllib.request.Request(url,headers={'User-Agent':'Mozilla/5.0','Accept':'text/csv'})
        with urllib.request.urlopen(req,timeout=20) as r:
            text=r.read().decode('utf-8','ignore')
        rows=_csv_rows(text)
        if rows:
            sheets.append({'name':'gid_'+str(gid),'values':rows})
    payload={'ok':True,'sheets':sheets}
    data=normalize_google_payload(payload)
    data['meta']['source']='Google Sheets LIVE (GViz CSV)'
    data['meta']['spreadsheetId']=SPREADSHEET_ID
    data['meta']['fetchedAt']=int(time.time()*1000)
    return data

def _load_local_cache():
    try:
        data=json.loads(LIVE_CACHE.read_text(encoding='utf-8'))
        if is_usable_normalized(data):
            data.setdefault('meta',{})['source']='Google Sheets LIVE CACHE'
            return data
    except Exception:
        pass
    return None

def is_usable_normalized(data):
    return isinstance(data,dict) and isinstance(data.get('records'),list) and len(data.get('records',[]))>0 and isinstance(data.get('months'),list)

def _load_snapshot():
    try:
        data=json.loads((ROOT/'data.json').read_text(encoding='utf-8'))
        if is_usable_normalized(data):
            data.setdefault('meta',{})['source']='LOCAL SNAPSHOT'
            return data
    except Exception:
        pass
    return None

def fetch_google_proxy():
    """Try direct Google Sheets first. Apps Script remains a compatibility fallback."""
    errors=[]
    try:
        data=fetch_google_csv()
        try:
            LIVE_CACHE.write_text(json.dumps(data,ensure_ascii=False),encoding='utf-8')
        except Exception:
            pass
        return data
    except Exception as e:
        errors.append('CSV export: '+str(e))
    try:
        data=fetch_google_gviz()
        try:
            LIVE_CACHE.write_text(json.dumps(data,ensure_ascii=False),encoding='utf-8')
        except Exception:
            pass
        return data
    except Exception as e:
        errors.append('direct: '+str(e))
    try:
        data=fetch_google_xlsx()
        if data.get('records'):
            try:
                LIVE_CACHE.write_text(json.dumps(data,ensure_ascii=False),encoding='utf-8')
            except Exception:
                pass
            return data
        errors.append("gviz: ma'lumot topilmadi")
    except Exception as e:
        errors.append('gviz: '+str(e))

    cfg=load_proxy_config(); url=str(cfg.get('url') or '').strip(); key=str(cfg.get('key') or '').strip()
    if url:
        sep='&' if '?' in url else '?'
        target=url + (sep + urllib.parse.urlencode({'key':key}) if key else '')
        req=urllib.request.Request(target,headers={'User-Agent':'MamuriyatLiveMonitor/18'})
        try:
            with urllib.request.urlopen(req,timeout=20) as r:
                data=normalize_google_payload(json.loads(r.read().decode('utf-8')))
            data['meta']['source']='Google Sheets LIVE (Apps Script)'
            data['meta']['fetchedAt']=int(time.time()*1000)
            try:
                LIVE_CACHE.write_text(json.dumps(data,ensure_ascii=False),encoding='utf-8')
            except Exception:
                pass
            return data
        except Exception as e:
            errors.append('Apps Script: '+str(e))

    cached=_load_local_cache()
    if cached:
        cached['meta']['warning']='Live Google Sheets vaqtincha ulanmayapti; oxirgi muvaffaqiyatli nusxa ishlatilmoqda.'
        return cached
    snapshot=_load_snapshot()
    if snapshot:
        snapshot['meta']['warning']='Google Sheets ulanmagan; ZIP ichidagi zaxira nusxa ishlatilmoqda.'
        return snapshot
    raise RuntimeError('Google Sheets ulanib bo‘lmadi: '+' | '.join(errors))

class Handler(SimpleHTTPRequestHandler):
    def end_headers(self):
        self.send_header('Cache-Control','no-store, no-cache, must-revalidate, max-age=0')
        self.send_header('Pragma','no-cache')
        self.send_header('Expires','0')
        super().end_headers()

    protocol_version = 'HTTP/1.1'
    def __init__(self,*a,**kw): super().__init__(*a,directory=str(ROOT),**kw)
    def log_message(self,fmt,*args): pass
    def _headers(self,code=200,ctype='application/json',length=None):
        self.send_response(code)
        self.send_header('Content-Type',ctype+'; charset=utf-8')
        self.send_header('Cache-Control','no-store, no-cache, must-revalidate, max-age=0')
        self.send_header('Pragma','no-cache'); self.send_header('Expires','0')
        self.send_header('Access-Control-Allow-Origin','*')
        self.send_header('Access-Control-Allow-Methods','GET,POST,OPTIONS')
        self.send_header('Access-Control-Allow-Headers','Content-Type')
        if length is not None: self.send_header('Content-Length',str(length))
        self.end_headers()
    def _json(self,obj,code=200):
        raw=json.dumps(obj,ensure_ascii=False).encode('utf-8')
        self._headers(code,'application/json',len(raw)); self.wfile.write(raw)
    def do_OPTIONS(self):
        self.send_response(204); self.send_header('Access-Control-Allow-Origin','*')
        self.send_header('Access-Control-Allow-Methods','GET,POST,OPTIONS')
        self.send_header('Access-Control-Allow-Headers','Content-Type'); self.send_header('Content-Length','0'); self.end_headers()
    def do_GET(self):
        route=self.path.split('?',1)[0]
        if route in ('/monitor','/monitor/','/monitor.html','/phone','/phone/','/tv','/tv/','/tv.html'):
            # MONITOR/PHONE must load the monitor document, never admin.html.
            # The monitor document detects monitor mode from both the query and path.
            self.path='/monitor.html'
            super().do_GET()
            return
        if route in ('/admin','/admin/'):
            self.path='/admin.html'
            super().do_GET()
            return
        if route in ('/','/index.html'):
            self.path='/admin.html'
            super().do_GET()
            return
        if route=='/api/health': self._json({'ok':True,'server_time':int(time.time()*1000),'ip':get_lan_ip(),'port':5000}); return
        if route=='/api/state':
            with lock: data=load_state()
            self._json(data); return
        if route=='/api/network':
            ip=get_lan_ip()
            self._json({'ok':True,'ip':ip,'admin_url':f'http://{ip}:5000/admin.html','monitor_url':f'http://{ip}:5000/monitor.html?mode=monitor'})
            return
        if route=='/api/google-data':
            try: self._json(fetch_google_proxy());
            except Exception as e: self._json({'ok':False,'error':str(e)},502)
            return
        super().do_GET()
    def do_POST(self):
        if self.path.split('?',1)[0]!='/api/state': self.send_error(404); return
        try:
            n=int(self.headers.get('Content-Length','0')); incoming=json.loads(self.rfile.read(n) or b'{}')
            for k in ('month','day','page','code','detail','ts'):
                if k not in incoming: raise ValueError('Missing field: '+k)
            incoming['month']=str(incoming['month']); incoming['day']=int(incoming['day'])
            incoming['page']=max(1,min(3,int(incoming['page']))); incoming['code']=str(incoming['code']); incoming['ts']=int(incoming['ts'])
            incoming['source']='admin'
            now=int(time.time()*1000)
            with lock:
                current=load_state(); current_ts=int(current.get('ts') or 0)
                # Recover automatically from a corrupted/future timestamp in state.json.
                # A previous build could contain a sentinel timestamp (e.g. 9999999999999),
                # which incorrectly caused every valid ADMIN update to be rejected as old.
                current_is_future_corrupt = current_ts > (now + 86400000)
                if (not current_is_future_corrupt) and incoming['ts'] < current_ts:
                    saved=current
                else:
                    incoming['version']=max(now,incoming['ts']); save_state(incoming); saved=incoming
            self._json({'ok':True,'state':saved})
        except Exception as e: self._json({'ok':False,'error':str(e)},400)

if __name__=='__main__':
    host,port='0.0.0.0',5000
    lan_ip=get_lan_ip()
    print('='*64); print("MA'MURIYAT BO'LIMI — LIVE MONITOR SERVER V18"); print('='*64)
    print(f'ADMIN:   http://{lan_ip}:{port}/admin.html')
    print(f'ADMIN local: http://127.0.0.1:{port}/admin.html')
    print(f'LAN IP:  {lan_ip}')
    print(f'MONITOR: http://{lan_ip}:{port}/monitor.html?mode=monitor')
    print(f'PHONE:   http://{lan_ip}:{port}/monitor.html?mode=monitor')
    print('ADMIN -> server state -> MONITOR: 0.5 soniyalik avtomatik sinxronizatsiya.')
    print('Google private-sheet proxy: /api/google-data (ixtiyoriy)')
    print('Faqat ADMIN boshqaradi; MONITOR faqat aks ettiradi.')
    print('CTRL+C — serverni to‘xtatish'); print('='*64)
    ThreadingHTTPServer((host,port),Handler).serve_forever()
