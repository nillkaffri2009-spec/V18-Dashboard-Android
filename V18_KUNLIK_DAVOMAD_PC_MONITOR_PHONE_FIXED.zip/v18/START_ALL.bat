@echo off
setlocal EnableExtensions EnableDelayedExpansion
cd /d "%~dp0"
set "PORT=5000"
set "PUBLIC_PORT=5001"
set "PROFILE=%LOCALAPPDATA%\MAMURIYAT_DASHBOARD_PROFILE"
set "CF=%~dp0cloudflared.exe"
set "LOG=%~dp0cloudflared_public.log"
set "URLFILE=%~dp0PHONE_PUBLIC_URL.txt"
set "LANFILE=%~dp0LAN_URLS.txt"
set "STATUS=%~dp0START_STATUS.txt"

echo ============================================================
echo MAMURIYAT DASHBOARD - ASOSIY DIZAYN 2 - V18
echo ADMIN + MONITOR + TELEFON + TV
echo Administrator huquqi KERAK EMAS
echo ============================================================

if exist "%~dp0STOP_ALL.bat" call "%~dp0STOP_ALL.bat"

set "PYEXE="
for /f "delims=" %%P in ('where python 2^>nul') do if not defined PYEXE set "PYEXE=%%P"
if not defined PYEXE for /f "delims=" %%P in ('where py 2^>nul') do if not defined PYEXE set "PYEXE=%%P"
if not defined PYEXE (
 echo XATO: Python topilmadi. Python 3 kerak.
 pause
 exit /b 1
)
if not exist "%PROFILE%" mkdir "%PROFILE%" >nul 2>&1

set "SERVER_LOG=%~dp0server_start.log"
>"%SERVER_LOG%" echo V18 server start: %date% %time%
>>"%SERVER_LOG%" echo Python: %PYEXE%

echo [1/4] SERVER ishga tushmoqda...
start "MAMURIYAT SERVER" /min "%PYEXE%" "%~dp0server.py" >>"%SERVER_LOG%" 2>&1
call :WAIT "http://127.0.0.1:%PORT%/api/health" 30
if errorlevel 1 (
 echo XATO: server 5000-portda ishga tushmadi.
 echo server_start.log ni tekshiring.
 type "%SERVER_LOG%"
 pause
 exit /b 1
)
echo SERVER OK.

set "LAN_IP="
for /f "delims=" %%I in ('powershell -NoProfile -Command "$r=Get-NetRoute -AddressFamily IPv4 -DestinationPrefix ''0.0.0.0/0'' -ErrorAction SilentlyContinue ^| Sort-Object RouteMetric ^| Select-Object -First 1; if($r){$a=Get-NetIPAddress -AddressFamily IPv4 -InterfaceIndex $r.ifIndex -ErrorAction SilentlyContinue ^| Where-Object {$_.IPAddress -notlike ''127.*'' -and $_.IPAddress -notlike ''169.254.*''} ^| Select-Object -First 1 -ExpandProperty IPAddress; if($a){$a}}"') do set "LAN_IP=%%I"
if not defined LAN_IP set "LAN_IP=127.0.0.1"

>"%LANFILE%" echo ADMIN:  http://%LAN_IP%:%PORT%/admin
>>"%LANFILE%" echo MONITOR: http://%LAN_IP%:%PORT%/monitor?mode=monitor^&design=2
>>"%LANFILE%" echo PHONE:   http://%LAN_IP%:%PORT%/phone?mode=monitor^&design=2
>>"%LANFILE%" echo TV:      http://%LAN_IP%:%PORT%/tv?mode=monitor^&design=2
>>"%LANFILE%" echo.
>>"%LANFILE%" echo MUHIM: Telefon va Smart TV bir xil Wi-Fi/LAN tarmog'ida bo'lsa shu LAN manzillardan foydalaning.

>"%STATUS%" echo SERVER=OK
>>"%STATUS%" echo LAN_IP=%LAN_IP%
>>"%STATUS%" echo MONITOR_LAN=http://%LAN_IP%:%PORT%/monitor?mode=monitor^&design=2
>>"%STATUS%" echo PHONE_LAN=http://%LAN_IP%:%PORT%/phone?mode=monitor^&design=2
>>"%STATUS%" echo TV_LAN=http://%LAN_IP%:%PORT%/tv?mode=monitor^&design=2

 echo [2/4] ADMIN ochilmoqda...
call :OPEN "http://127.0.0.1:%PORT%/admin"
echo [3/4] MONITOR ochilmoqda...
call :OPEN "http://127.0.0.1:%PORT%/monitor?mode=monitor&design=2"

echo [4/4] Telefon/TV URL tayyorlanmoqda...
if exist "%CF%" (
  start "MAMURIYAT PUBLIC PROXY" /min "%PYEXE%" "%~dp0public_monitor_proxy.py"
  call :WAIT "http://127.0.0.1:%PUBLIC_PORT%/monitor" 15
  if not errorlevel 1 (
    del "%LOG%" >nul 2>&1
    start "CLOUDFLARE PUBLIC MONITOR" /min cmd /c "cd /d ""%~dp0"" && cloudflared.exe tunnel --no-autoupdate --url http://127.0.0.1:%PUBLIC_PORT% > cloudflared_public.log 2>&1"
    set "PUBLIC="
    for /l %%N in (1,1,30) do (
      timeout /t 1 /nobreak >nul
      for /f "delims=" %%U in ('powershell -NoProfile -Command "$s=Get-Content -Raw -LiteralPath '%LOG%' -ErrorAction SilentlyContinue; [regex]::Match($s,'https://[a-z0-9-]+\.trycloudflare\.com').Value"') do if not defined PUBLIC set "PUBLIC=%%U"
      if defined PUBLIC goto PUBLIC_OK
    )
  )
)

echo PUBLIC tunnel topilmadi. LAN URL baribir tayyor.
>"%URLFILE%" echo Public tunnel hozircha mavjud emas.
>>"%URLFILE%" echo LAN PHONE: http://%LAN_IP%:%PORT%/phone?mode=monitor^&design=2
>>"%URLFILE%" echo LAN TV: http://%LAN_IP%:%PORT%/tv?mode=monitor^&design=2
goto DONE

:PUBLIC_OK
>"%URLFILE%" echo %PUBLIC%/monitor?mode=monitor^&design=2
>>"%URLFILE%" echo Public HTTPS monitor: %PUBLIC%/monitor?mode=monitor^&design=2
>>"%URLFILE%" echo LAN PHONE: http://%LAN_IP%:%PORT%/phone?mode=monitor^&design=2
>>"%URLFILE%" echo LAN TV: http://%LAN_IP%:%PORT%/tv?mode=monitor^&design=2

echo Public HTTPS URL tayyor.
:DONE
echo.
echo ============================================================
echo ADMIN : http://127.0.0.1:%PORT%/admin
echo MONITOR: http://%LAN_IP%:%PORT%/monitor?mode=monitor^&design=2
echo PHONE:   http://%LAN_IP%:%PORT%/phone?mode=monitor^&design=2
echo TV:      http://%LAN_IP%:%PORT%/tv?mode=monitor^&design=2
echo ============================================================
echo LAN_URLS.txt va PHONE_PUBLIC_URL.txt fayllarini ham tekshirishingiz mumkin.
echo STOP_ALL.bat - hammasini to'xtatadi.
echo.
pause
endlocal
exit /b 0

:OPEN
set "TARGET=%~1"
set "CHROME="
if exist "%ProgramFiles%\Google\Chrome\Application\chrome.exe" set "CHROME=%ProgramFiles%\Google\Chrome\Application\chrome.exe"
if not defined CHROME if exist "%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe" set "CHROME=%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe"
if not defined CHROME if exist "%LocalAppData%\Google\Chrome\Application\chrome.exe" set "CHROME=%LocalAppData%\Google\Chrome\Application\chrome.exe"
if defined CHROME start "MAMURIYAT DASHBOARD" "%CHROME%" --user-data-dir="%PROFILE%" --no-first-run --no-default-browser-check --new-window "%TARGET%"
if not defined CHROME start "MAMURIYAT DASHBOARD" "%TARGET%"
exit /b 0

:WAIT
set "U=%~1"
set /a N=0
:W
curl -fsS --max-time 2 "%U%" >nul 2>&1
if not errorlevel 1 exit /b 0
set /a N+=1
if !N! GEQ %~2 exit /b 1
timeout /t 1 /nobreak >nul
goto W
