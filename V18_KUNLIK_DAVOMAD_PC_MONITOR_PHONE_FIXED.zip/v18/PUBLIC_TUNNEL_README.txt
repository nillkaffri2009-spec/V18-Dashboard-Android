MAMURIYAT LIVE MONITOR - DOIMIY INTERNET REJIMI

XULOSA:
- Bir xil Wi-Fi/LAN: LAN manzil avtomatik ishlaydi.
- Turli Wi-Fi/mobil internet: Named Cloudflare Tunnel kerak.
- Quick Tunnel (trycloudflare.com) DOIMIY EMAS; qayta ishga tushganda URL o'zgaradi.
- Doimiy manzil uchun Cloudflare account va Cloudflare'da boshqariladigan domain kerak.

1) Cloudflare'da domainni qo'shing.
2) Networking > Tunnels > Create Tunnel.
3) Windows uchun connector/tunnel tokenini oling.
4) PUBLIC_TUNNEL_SETUP.bat ni ishga tushiring va tokenni kiriting.
5) Tunnel Routes > Published application orqali masalan:
   monitor.example.uz -> http://localhost:5000
   yoki kerak bo'lsa -> http://localhost:5001
6) START_ALL.bat ni ishga tushiring.
7) Telefon doim bir xil manzilni ochadi:
   https://monitor.example.uz/monitor

XAVFSIZLIK:
- Admin manzilini public hostname orqali chiqarmang.
- Faqat /monitor yo'lini public qilish tavsiya etiladi.
- cloudflare_token.txt maxfiy saqlansin.
