from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from urllib.request import urlopen, Request
from urllib.parse import urlsplit
import threading

UPSTREAM='http://127.0.0.1:5000'
ALLOWED_PREFIX=('/monitor','/monitor.html','/api/state','/api/network','/api/google-data')

class H(BaseHTTPRequestHandler):
    protocol_version='HTTP/1.1'
    def log_message(self, fmt, *args): pass
    def _send(self, code, body, ctype='text/plain; charset=utf-8'):
        b=body if isinstance(body,bytes) else body.encode('utf-8')
        self.send_response(code)
        self.send_header('Content-Type',ctype)
        self.send_header('Cache-Control','no-store')
        self.send_header('Access-Control-Allow-Origin','*')
        self.send_header('Content-Length',str(len(b)))
        self.end_headers(); self.wfile.write(b)
    def do_OPTIONS(self): self._send(204,b'')
    def do_POST(self): self._send(403,'Public monitor is read-only.')
    def do_GET(self):
        path=urlsplit(self.path).path
        if path=='/': path='/monitor'
        if path not in ('/monitor','/monitor.html') and not path.startswith('/api/state') and not path.startswith('/api/network') and not path.startswith('/api/google-data'):
            return self._send(403,'Forbidden')
        target=UPSTREAM+self.path
        try:
            req=Request(target,headers={'User-Agent':'MamuriyatPublicMonitor/1'})
            with urlopen(req,timeout=15) as r:
                body=r.read(); ctype=r.headers.get('Content-Type','text/plain')
                self._send(r.status,body,ctype)
        except Exception as e:
            self._send(502,'Upstream server unavailable: '+str(e))

if __name__=='__main__':
    print('Public read-only proxy: http://127.0.0.1:5001/monitor')
    ThreadingHTTPServer(('127.0.0.1',5001),H).serve_forever()
