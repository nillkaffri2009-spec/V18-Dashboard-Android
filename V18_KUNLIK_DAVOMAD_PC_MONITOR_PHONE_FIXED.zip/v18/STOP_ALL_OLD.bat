@echo off
cd /d "%~dp0"
taskkill /FI "WINDOWTITLE eq MAMURIYAT LIVE SERVER*" /T /F >nul 2>&1
for /f "tokens=5" %%p in ('netstat -ano ^| findstr ":5000" ^| findstr "LISTENING"') do taskkill /PID %%p /F >nul 2>&1
echo Server stopped.
