@echo off
setlocal EnableExtensions EnableDelayedExpansion
cd /d "%~dp0"
set "PORT=5000"
set "PUBLIC_PORT=5001"
set "CF=%~dp0cloudflared.exe"
set "LOG=%~dp0cloudflared_public.log"
set "URLFILE=%~dp0PHONE_PUBLIC_URL.txt"

echo MAMURIYAT - TELEFON 4G / BOSHQA WIFI
where py >nul 2>&1 || (echo Python topilmadi.&pause&exit /b 1)
if not exist "%CF%" (echo cloudflared.exe topilmadi.&pause&exit /b 1)

curl -fsS --max-time 3 http://127.0.0.1:%PORT%/api/health >nul 2>&1
if errorlevel 1 (
  echo Server ishlamayapti, ishga tushirilmoqda...
  start "MAMURIYAT SERVER" /min cmd /c "cd /d ""%~dp0"" && py -3 server.py"
  for /l %%N in (1,1,30) do (
    timeout /t 1 /nobreak >nul
    curl -fsS --max-time 2 http://127.0.0.1:%PORT%/api/health >nul 2>&1
    if not errorlevel 1 goto SERVER_OK
  )
  echo XATO: server ishga tushmadi.&pause&exit /b 1
)
:SERVER_OK
curl -fsS --max-time 3 http://127.0.0.1:%PUBLIC_PORT%/monitor >nul 2>&1
if errorlevel 1 start "MAMURIYAT PUBLIC PROXY" /min cmd /c "cd /d ""%~dp0"" && py -3 public_monitor_proxy.py"
for /l %%N in (1,1,20) do (
 timeout /t 1 /nobreak >nul
 curl -fsS --max-time 2 http://127.0.0.1:%PUBLIC_PORT%/monitor >nul 2>&1
 if not errorlevel 1 goto PROXY_OK
)
echo XATO: public proxy 5001-portda ishga tushmadi.&pause&exit /b 1
:PROXY_OK
del "%LOG%" >nul 2>&1
start "CLOUDFLARE PUBLIC MONITOR" /min cmd /c "cd /d ""%~dp0"" && cloudflared.exe tunnel --no-autoupdate --url http://127.0.0.1:%PUBLIC_PORT% > cloudflared_public.log 2>&1
set "PUBLIC="
for /l %%N in (1,1,40) do (
 timeout /t 1 /nobreak >nul
 for /f "delims=" %%U in ('powershell -NoProfile -Command "$s=Get-Content -Raw -LiteralPath '%LOG%' -ErrorAction SilentlyContinue; [regex]::Match($s,'https://[a-z0-9-]+\.trycloudflare\.com').Value"') do if not defined PUBLIC set "PUBLIC=%%U"
 if defined PUBLIC goto GOT
)
echo XATO: HTTPS public URL olinmadi. cloudflared_public.log ni tekshiring.&pause&exit /b 1
:GOT
>"%URLFILE%" echo %PUBLIC%/monitor
echo.
echo TELEFON UCHUN URL:
echo %PUBLIC%/monitor
echo.
start "PHONE PUBLIC URL" notepad.exe "%URLFILE%"
pause
endlocal
