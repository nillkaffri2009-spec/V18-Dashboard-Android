@echo off
start "MAMURIYAT MONITOR" "http://10.142.29.9:5000/monitor?design=2&v=20260824-final"
