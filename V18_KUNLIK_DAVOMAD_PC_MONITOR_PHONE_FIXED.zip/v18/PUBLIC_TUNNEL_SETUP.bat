@echo off
setlocal EnableExtensions
cd /d "%~dp0"
echo ============================================================
echo MAMURIYAT - DOIMIY INTERNET MANZILI SOZLASH
 echo ============================================================
echo.
echo Bu bosqich uchun Cloudflare account + Cloudflare'dagi domain
 echo va Named Tunnel token kerak.
echo Tokenni Cloudflare Dashboard ^> Networking ^> Tunnels ^> Connectors
 echo qismidan oling.
echo.
set /p TOKEN=Cloudflare Tunnel tokenini shu yerga kiriting: 
if "%TOKEN%"=="" (
  echo Token kiritilmadi.
  pause
  exit /b 1
)
>cloudflare_token.txt echo %TOKEN%
>PUBLIC_URL.txt echo DOIMIY PUBLIC URL: Cloudflare Tunnel'da tanlangan hostname
>>PUBLIC_URL.txt echo Masalan: https://monitor.example.uz/monitor
>>PUBLIC_URL.txt echo Hostname Cloudflare Dashboard > Networking > Tunnels > Routes > Published application orqali belgilanadi.
echo.
echo Token saqlandi. Endi START_ALL.bat ni ishga tushiring.
echo.
echo MUHIM: tokenni hech kimga yubormang.
pause
endlocal
