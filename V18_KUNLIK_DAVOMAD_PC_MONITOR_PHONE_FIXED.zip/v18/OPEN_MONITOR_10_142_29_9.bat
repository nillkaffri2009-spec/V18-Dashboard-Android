@echo off
start "" "http://10.142.29.9:5000/monitor?mode=monitor&design=2&v=20260824-final"
