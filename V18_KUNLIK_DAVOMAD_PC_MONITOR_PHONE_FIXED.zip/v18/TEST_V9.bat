@echo off
cd /d "%~dp0"
echo === MAMURIYAT V9 TEST ===
echo [1] Health
curl -sS http://127.0.0.1:5000/api/health
echo.
echo [2] Monitor route
curl -sSI http://127.0.0.1:5000/monitor | findstr /R /C:"HTTP/" /C:"Content-Type"
echo [3] Admin route
curl -sSI http://127.0.0.1:5000/admin | findstr /R /C:"HTTP/" /C:"Content-Type"
echo [4] Network API
curl -sS http://127.0.0.1:5000/api/network
echo.
echo If all four return HTTP 200 / ok:true, server-side routing is healthy.
pause
