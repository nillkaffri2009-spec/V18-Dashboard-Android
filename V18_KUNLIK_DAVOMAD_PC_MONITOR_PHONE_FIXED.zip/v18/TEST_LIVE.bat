@echo off
cd /d "%~dp0"
echo Checking live server...
curl -s http://127.0.0.1:5000/api/health
echo.
pause
