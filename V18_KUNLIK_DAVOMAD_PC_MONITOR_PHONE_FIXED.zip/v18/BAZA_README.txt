V18 KUNLIK DAVOMAD — BAZA INTEGRATSIYA

Asosiy baza: Dashboard_BAZA_Kunlik_davomad.xlsx
Dashboard bo'limlari: 21010, 21111, 21113, 21120, 21130, 21140.
Paket ichidagi data.json ushbu bazadan qayta tuzildi.
Bazada hozir mavjud oylar: Yanvar–Iyul 2026. Avgust/Sentabr bu yuborilgan XLSX faylda topilmadi; shuning uchun ular uydirma ma'lumot bilan to'ldirilmadi.
Dashboard ishga tushganda eng oxirgi mavjud oy — Iyul — avtomatik tanlanadi.

PC/Admin: START_ALL.bat
Monitor: START_ALL.bat monitor oynasini ham ochadi; monitor read-only va admin holatini sinxron kuzatadi.
Phone (LAN): telefon va PC bir Wi-Fi/LAN tarmog'ida bo'lsa START_PHONE_FIXED.bat / CHECK_PHONE_FIXED.bat ko'rsatmalaridan foydalaning.
APK: .github/workflows/build-apk.yml GitHub Actions orqali standalone APK yig'ish uchun.

Google Sheets LIVE mavjud bo'lsa server.py undan yangiroq ma'lumot olishga urinadi; ulanish bo'lmasa paketdagi tekshirilgan Excel snapshot ishlaydi.
