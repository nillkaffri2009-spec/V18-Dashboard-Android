@echo off
for /f "tokens=2 delims=:" %%A in ('netstat -ano ^| findstr ":5001" ^| findstr "LISTENING"') do taskkill /PID %%A /F >nul 2>&1
taskkill /IM cloudflared.exe /F >nul 2>&1
taskkill /FI "WINDOWTITLE eq MAMURIYAT SERVER*" /T /F >nul 2>&1
taskkill /FI "WINDOWTITLE eq MAMURIYAT PUBLIC PROXY*" /T /F >nul 2>&1
taskkill /FI "WINDOWTITLE eq CLOUDFLARE PUBLIC MONITOR*" /T /F >nul 2>&1
echo MAMURIYAT public monitor to'xtatildi.
pause
