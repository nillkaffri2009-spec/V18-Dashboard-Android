@echo off
setlocal
cd /d "%~dp0"
echo ============================================================
echo MAMURIYAT - TELEFON / SMART TV MONITOR
 echo ============================================================
if exist LAN_URLS.txt type LAN_URLS.txt
if exist PHONE_PUBLIC_URL.txt (
 echo.
 echo PUBLIC HTTPS:
 type PHONE_PUBLIC_URL.txt
)
echo.
echo Bir xil Wi-Fi bo'lsa: LAN manzilini ishlating.
echo 4G/boshqa Wi-Fi bo'lsa: PHONE_PUBLIC_URL.txt dagi HTTPS manzilini ishlating.
echo URL oxirida /monitor yoki /tv bo'lishi kerak.
pause
endlocal
