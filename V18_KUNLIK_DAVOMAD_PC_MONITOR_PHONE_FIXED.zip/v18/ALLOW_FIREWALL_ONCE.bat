@echo off
echo Bu versiyada Firewall uchun Administrator huquqi talab qilinmaydi.
echo Telefon ulanishi Cloudflare HTTPS tunnel orqali amalga oshiriladi.
pause
