@echo off
setlocal EnableExtensions
cd /d "%~dp0"
set "LAN_IP=10.142.29.9"
set "PORT=5000"

echo ============================================================
echo MAMURIYAT BO'LIMI - LIVE MONITOR V10.6
echo ============================================================
echo LAN IP: %LAN_IP%
echo PORT:   %PORT%
echo.
echo ADMIN:   http://%LAN_IP%:%PORT%/admin
echo MONITOR: http://%LAN_IP%:%PORT%/monitor
echo PHONE/TV:http://%LAN_IP%:%PORT%/monitor
echo.
echo Windows Administrator huquqi bu skript tomonidan SO'RALMAYDI.
echo.

rem Stop old copy of this project's server only by closing the known console window if present.
taskkill /FI "WINDOWTITLE eq MAMURIYAT SERVER V10.6*" /T /F >nul 2>&1

start "MAMURIYAT SERVER V10.6" /min cmd /c "cd /d ""%~dp0"" && py -3 server.py"
timeout /t 2 /nobreak >nul

curl -fsS --max-time 3 http://127.0.0.1:5000/api/health >health_check.json 2>nul
if errorlevel 1 (
  echo XATO: server 5000-portda ishga tushmadi.
  echo server oynasini tekshiring.
  pause
  exit /b 1
)

>PHONE_URL.txt echo http://%LAN_IP%:%PORT%/monitor
>>PHONE_URL.txt echo Telefon va Android TV kompyuter bilan bir xil Wi-Fi/LAN tarmog'ida bo'lsin.
>>PHONE_URL.txt echo Brauzerga manzilni TO'G'RIDAN yozing. HTTPS yoki 127.0.0.1 ishlatmang.
>>PHONE_URL.txt echo Agar PCda ochilib, telefon/TVda ochilmasa, Windows Firewall 5000-portni bloklayotgan bo'lishi mumkin.

start "ADMIN" "http://%LAN_IP%:%PORT%/admin"
timeout /t 1 /nobreak >nul
start "MONITOR" "http://%LAN_IP%:%PORT%/monitor"

echo.
echo ============================================================
echo SERVER ISHLADI
 echo PC:      http://%LAN_IP%:%PORT%/monitor
 echo PHONE:   http://%LAN_IP%:%PORT%/monitor
 echo TV:      http://%LAN_IP%:%PORT%/monitor
 echo ADMIN:   http://%LAN_IP%:%PORT%/admin
 echo ============================================================
endlocal
exit /b 0
