@echo off
setlocal
cls
echo ============================================================
echo MAMURIYAT V10.6 - WIFI/LAN DIAGNOSTIKA
echo ============================================================
echo.
echo [1] Kompyuter IPv4 manzillari:
ipconfig | findstr /I "IPv4"
echo.
echo [2] 5000-port tinglayaptimi:
netstat -ano | findstr ":5000"
echo.
echo [3] Lokal server:
curl -fsS http://127.0.0.1:5000/api/health
if errorlevel 1 echo XATO: lokal server javob bermadi.
echo.
echo [4] Monitor marshruti:
curl -I --max-time 3 http://127.0.0.1:5000/monitor
if errorlevel 1 echo XATO: /monitor marshruti ishlamayapti.
echo.
echo [5] Telefon/TV manzili:
echo http://10.142.29.9:5000/monitor
echo.
echo Agar [1]-[4] ishlasa, lekin telefon/TV ochmasa:
echo   - Guest Wi-Fi emasligini tekshiring;
echo   - Routerda AP/Client Isolation o'chirilgan bo'lsin;
echo   - VPNni o'chiring;
echo   - ALLOW_FIREWALL_ONCE.bat ni bir marta administrator sifatida ishga tushiring.
echo.
pause
endlocal
