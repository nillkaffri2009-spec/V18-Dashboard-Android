@echo off
setlocal EnableExtensions
cd /d "%~dp0"
echo ============================================================
echo MAMURIYAT BO'LIMI - HAMMA ISHGA TUSHIRILGAN OYNALARNI TO'XTATISH
echo ============================================================

for /f "tokens=5" %%P in ('netstat -ano ^| findstr ":5000" ^| findstr LISTENING') do taskkill /PID %%P /T /F >nul 2>&1
for /f "tokens=5" %%P in ('netstat -ano ^| findstr ":5001" ^| findstr LISTENING') do taskkill /PID %%P /T /F >nul 2>&1

powershell -NoProfile -ExecutionPolicy Bypass -Command "$ps=Get-CimInstance Win32_Process -Filter 'Name = ''cloudflared.exe'''; foreach($p in $ps){try{Stop-Process -Id $p.ProcessId -Force -ErrorAction SilentlyContinue}catch{}}" >nul 2>&1

REM Faqat ushbu Dashboard tomonidan ochilgan Chrome profili yopiladi.
powershell -NoProfile -ExecutionPolicy Bypass -Command "$procs=Get-CimInstance Win32_Process | Where-Object {$_.CommandLine -like '*MAMURIYAT_DASHBOARD_PROFILE*'}; foreach($p in $procs){cmd /c taskkill /PID $($p.ProcessId) /T /F >$null 2>&1}" >nul 2>&1

REM Eski server/proxy oynalari ham yopiladi.
taskkill /FI "WINDOWTITLE eq MAMURIYAT SERVER*" /T /F >nul 2>&1
taskkill /FI "WINDOWTITLE eq MAMURIYAT PUBLIC PROXY*" /T /F >nul 2>&1
taskkill /FI "WINDOWTITLE eq MAMURIYAT PHONE TUNNEL*" /T /F >nul 2>&1

echo.
echo TAYYOR: server, proxy, tunnel va Dashboard tomonidan ochilgan ekranlar to'xtatildi.
timeout /t 2 /nobreak >nul
endlocal
exit /b 0
