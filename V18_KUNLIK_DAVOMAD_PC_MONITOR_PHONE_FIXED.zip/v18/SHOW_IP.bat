@echo off
setlocal
for /f "delims=" %%I in ('powershell -NoProfile -Command "$x=Get-NetIPAddress -AddressFamily IPv4 ^| Where-Object {$_.IPAddress -notlike '127.*' -and $_.IPAddress -notlike '169.254.*'} ^| Select-Object -First 1 -ExpandProperty IPAddress; Write-Output $x"') do set "LAN_IP=%%I"
echo Kompyuter LAN IP: %LAN_IP%
echo Telefon URL: http://%LAN_IP%:5000/monitor.html?mode=monitor
echo.
echo 127.0.0.1 = FAQAT SHU KOMPYUTER. TELEFONDA UNI ISHLATMANG.
pause
