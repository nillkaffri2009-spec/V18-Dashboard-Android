const SPREADSHEET_ID = '1IWyUdorge58MbvpNlB5Z08Rawm8AdoeHinxgjiFktF4';
const ACCESS_KEY = 'CHANGE_THIS_KEY';

function doGet(e) {
  if ((e.parameter.key || '') !== ACCESS_KEY) {
    return ContentService.createTextOutput(JSON.stringify({ok:false,error:'forbidden'}))
      .setMimeType(ContentService.MimeType.JSON);
  }
  const ss = SpreadsheetApp.openById(SPREADSHEET_ID);
  const sheets = ss.getSheets();
  const result = {ok:true, sheets:[]};
  sheets.forEach(sh => {
    const values = sh.getDataRange().getValues();
    result.sheets.push({name: sh.getName(), values: values});
  });
  return ContentService.createTextOutput(JSON.stringify(result))
    .setMimeType(ContentService.MimeType.JSON);
}
