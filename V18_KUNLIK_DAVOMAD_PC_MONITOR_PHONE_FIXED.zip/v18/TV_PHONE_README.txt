TV / TELEFON UCHUN

1) START_ALL.bat ni kompyuterda ishga tushiring.
2) Agar TV kompyuterga HDMI orqali ulangan bo'lsa, Monitor oynasini TV ekraniga ko'chiring.
3) Agar TV alohida Smart TV qurilmasi bo'lsa, PHONE_PUBLIC_URL.txt ichidagi https://...trycloudflare.com/monitor manzilini TV brauzeriga yozing.
4) Telefon boshqa Wi-Fi yoki 4G'da bo'lsa ham shu HTTPS manzil ishlaydi.
5) Telefon/TV bir xil Wi-Fi'da bo'lsa LAN_URLS.txt dagi MONITOR LAN manzilidan foydalanish mumkin.
6) 127.0.0.1 faqat server ishlayotgan kompyuterning o'zida ishlaydi; alohida TV/telefon uchun ishlatilmaydi.
