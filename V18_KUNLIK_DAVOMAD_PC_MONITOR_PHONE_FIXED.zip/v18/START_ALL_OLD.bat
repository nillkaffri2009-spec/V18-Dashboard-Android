@echo off
setlocal EnableExtensions
cd /d "%~dp0"
set "PORT=5000"
set "CFPORT=5001"

echo ============================================================
echo MAMURIYAT BO'LIMI - LIVE MONITOR V10.8
echo ============================================================

echo [1/5] Eski server/proxy jarayonlarini to'xtatish...
for /f "tokens=5" %%P in ('netstat -ano ^| findstr ":5000" ^| findstr "LISTENING"') do taskkill /PID %%P /T /F >nul 2>&1
taskkill /FI "WINDOWTITLE eq MAMURIYAT SERVER V10.8*" /T /F >nul 2>&1
taskkill /IM cloudflared.exe /F >nul 2>&1
taskkill /FI "WINDOWTITLE eq MAMURIYAT SERVER V10.8*" /T /F >nul 2>&1
taskkill /IM cloudflared.exe /F >nul 2>&1

echo [2/5] Windows Firewall uchun 5000/5001 portlar tekshirilmoqda...
netsh advfirewall firewall add rule name="MAMURIYAT Dashboard 5000" dir=in action=allow protocol=TCP localport=5000 >nul 2>&1
netsh advfirewall firewall add rule name="MAMURIYAT Public Proxy 5001" dir=in action=allow protocol=TCP localport=5001 >nul 2>&1

echo [3/5] Python server ishga tushmoqda...
start "MAMURIYAT SERVER V10.8" /min cmd /c "cd /d ""%~dp0"" && py -3 server.py"
timeout /t 2 /nobreak >nul
curl -fsS --max-time 5 http://127.0.0.1:%PORT%/api/health >health_check.json 2>nul
if errorlevel 1 (
  echo XATO: server %PORT%-portda ishga tushmadi.
  echo server oynasini tekshiring.
  pause
  exit /b 1
)

for /f "tokens=2 delims=:" %%A in ('ipconfig ^| findstr /R /C:"IPv4 Address" /C:"IPv4-адрес"') do set "LAN_IP=%%A"
set "LAN_IP=%LAN_IP: =%"
if not defined LAN_IP set "LAN_IP=127.0.0.1"

>PHONE_URL.txt echo LAN Monitor: http://%LAN_IP%:%PORT%/monitor
>>PHONE_URL.txt echo LAN manzil faqat bir xil Wi-Fi/LAN uchun.
>>PHONE_URL.txt echo Doimiy Internet manzili uchun PUBLIC_TUNNEL_SETUP.bat ni bir marta sozlang.

start "ADMIN" "http://127.0.0.1:%PORT%/admin"
timeout /t 1 /nobreak >nul
start "MONITOR" "http://127.0.0.1:%PORT%/monitor"

echo [4/5] Doimiy tunnel sozlamasi tekshirilmoqda...
if exist cloudflare_token.txt (
  echo Token topildi. Named Cloudflare Tunnel ishga tushiriladi.
  start "MAMURIYAT CLOUDFLARE TUNNEL" /min cmd /c "cd /d ""%~dp0"" && cloudflared.exe tunnel run --token-file cloudflare_token.txt"
  timeout /t 4 /nobreak >nul
  if exist PUBLIC_URL.txt (
    echo [5/5] Doimiy Public Monitor manzili:
    type PUBLIC_URL.txt
  ) else (
    echo Tunnel ishga tushdi. Cloudflare Dashboard'dagi Hostname manzilidan foydalaning.
  )
) else (
  echo Token topilmadi. LAN rejimi ishlayapti.
  echo Doimiy Internet manzili uchun PUBLIC_TUNNEL_SETUP.bat ni ishga tushiring.
)

echo.
echo ============================================================
echo TAYYOR
 echo LAN Monitor: http://%LAN_IP%:%PORT%/monitor
 echo Admin:       http://%LAN_IP%:%PORT%/admin
 echo.
echo Telefon turli Wi-Fi'da bo'lsa, doimiy tunnel sozlang.
echo ============================================================
endlocal
exit /b 0
