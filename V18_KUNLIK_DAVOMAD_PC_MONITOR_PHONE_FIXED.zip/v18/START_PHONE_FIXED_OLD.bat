@echo off
setlocal EnableExtensions EnableDelayedExpansion
cd /d "%~dp0"

:: MAMURIYAT — TELEFON UCHUN ISHONCHLI ULASH
:: 1) LAN: bir xil Wi-Fi bo'lsa http://PC-IP:5000/monitor
:: 2) 4G/boshqa Wi-Fi: Quick Tunnel orqali HTTPS manzil beradi

net session >nul 2>&1
if not "%errorlevel%"=="0" (
  echo Administrator huquqi kerak. Qayta administrator sifatida ochilmoqda...
  powershell -NoProfile -ExecutionPolicy Bypass -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
  exit /b
)

set PORT=5000
set PROXYPORT=5001
set CF=%~dp0cloudflared.exe
set LOG=%~dp0cloudflared_phone.log
set URLFILE=%~dp0PHONE_PUBLIC_URL.txt

for /f "tokens=5" %%P in ('netstat -ano ^| findstr ":5000" ^| findstr "LISTENING"') do taskkill /PID %%P /T /F >nul 2>&1
for /f "tokens=5" %%P in ('netstat -ano ^| findstr ":5001" ^| findstr "LISTENING"') do taskkill /PID %%P /T /F >nul 2>&1
taskkill /IM cloudflared.exe /F >nul 2>&1

netsh advfirewall firewall delete rule name="MAMURIYAT Dashboard 5000" >nul 2>&1
netsh advfirewall firewall add rule name="MAMURIYAT Dashboard 5000" dir=in action=allow protocol=TCP localport=5000 profile=any >nul
netsh advfirewall firewall delete rule name="MAMURIYAT Public Monitor 5001" >nul 2>&1
netsh advfirewall firewall add rule name="MAMURIYAT Public Monitor 5001" dir=in action=allow protocol=TCP localport=5001 profile=any >nul

if not exist "%CF%" (
  echo XATO: cloudflared.exe topilmadi.
  pause
  exit /b 1
)

echo [1/4] Asosiy server ishga tushmoqda...
start "MAMURIYAT SERVER" /min cmd /c "cd /d ""%~dp0"" && py -3 server.py"
timeout /t 2 /nobreak >nul
curl -fsS --max-time 5 http://127.0.0.1:5000/api/health >nul 2>&1
if errorlevel 1 (
  echo XATO: 5000-port ishlamadi.
  pause
  exit /b 1
)

echo [2/4] Read-only monitor proxy ishga tushmoqda...
start "MAMURIYAT PUBLIC PROXY" /min cmd /c "cd /d ""%~dp0"" && py -3 public_monitor_proxy.py"
timeout /t 2 /nobreak >nul
curl -fsS --max-time 5 http://127.0.0.1:5001/monitor >nul 2>&1
if errorlevel 1 (
  echo XATO: 5001-port proxy ishlamadi.
  pause
  exit /b 1
)

for /f "delims=" %%I in ('powershell -NoProfile -Command "$x=Get-NetIPAddress -AddressFamily IPv4 ^| Where-Object {$_.IPAddress -notlike '127.*' -and $_.IPAddress -notlike '169.254.*'} ^| Select-Object -First 1 -ExpandProperty IPAddress; Write-Output $x"') do set LAN_IP=%%I
if not defined LAN_IP set LAN_IP=127.0.0.1

>PHONE_URL.txt echo LAN Monitor: http://%LAN_IP%:5000/monitor
>>PHONE_URL.txt echo LAN faqat telefon va PC bir xil Wi-Fi/LAN tarmog'ida bo'lsa ishlaydi.

if exist "%LOG%" del "%LOG%" >nul 2>&1
if exist "%URLFILE%" del "%URLFILE%" >nul 2>&1

echo [3/4] Telefon uchun HTTPS manzil yaratilmoqda...
start "MAMURIYAT PHONE TUNNEL" /min cmd /c "cd /d ""%~dp0"" && cloudflared.exe tunnel --no-autoupdate --url http://127.0.0.1:5001 > cloudflared_phone.log 2>&1"

set PUBLIC=
for /l %%N in (1,1,40) do (
  timeout /t 1 /nobreak >nul
  for /f "tokens=5" %%U in ('findstr /R /C:"https://.*trycloudflare.com" "%LOG%" 2^>nul') do if not defined PUBLIC set PUBLIC=%%U
  if defined PUBLIC goto GOTURL
)

echo XATO: HTTPS manzil olilmadi.
echo.
echo LAN manzil: http://%LAN_IP%:5000/monitor
 echo Agar shu manzil telefonida ochilmasa, telefon va PC bir xil Wi-Fi emas yoki routerda AP Isolation yoqilgan.
echo cloudflared_phone.log ni tekshiring.
pause
exit /b 1

:GOTURL
>"%URLFILE%" echo %PUBLIC%/monitor

echo [4/4] TAYYOR!
echo.
echo ============================================================
echo TELEFON UCHUN HTTPS MANZIL:
echo %PUBLIC%/monitor
echo ============================================================
echo.
echo Telefon 4G yoki boshqa Wi-Fi'da bo'lsa ham shu HTTPS manzilni ochadi.
echo URL PHONE_PUBLIC_URL.txt fayliga saqlandi.
echo.
start "PHONE PUBLIC URL" notepad.exe "%URLFILE%"
endlocal
