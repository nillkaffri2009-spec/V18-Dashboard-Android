ZIP-09 — TELEFON 4G / BOSHQA WIFI UCHUN

MUAMMO:
10.142.29.9 — ichki LAN IP. Telefon 4G'da bu manzilni ocholmaydi.

YECHIM:
START_PHONE_4G.bat
  1) server.py -> 127.0.0.1:5000
  2) public_monitor_proxy.py -> 127.0.0.1:5001
  3) Cloudflare Quick Tunnel -> 5001
  4) yangi HTTPS URL -> PUBLIC_URL.txt

TELEFON:
PUBLIC_URL.txt ichidagi https://...trycloudflare.com/monitor manzilini oching.

MUHIM:
- Har qayta ishga tushganda Quick Tunnel yangi URL berishi mumkin.
- Doimiy bitta manzil uchun Cloudflare Named Tunnel + o'zingizga tegishli domain kerak.
- Public tomonda faqat Monitor va kerakli GET API'lar ochiladi; POST /api/state bloklangan.
- Kompyuter ishlayotgan va internetga ulangan bo'lishi shart.

TO'XTATISH:
STOP_PHONE_4G.bat
