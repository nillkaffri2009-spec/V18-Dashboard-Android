@echo off
setlocal
cd /d "%~dp0"
echo ===============================================
echo TELEFON PUBLIC URL TEKSHIRUVI
echo ===============================================
if not exist "PHONE_PUBLIC_URL.txt" (echo URL fayli topilmadi.&goto END)
echo.
type "PHONE_PUBLIC_URL.txt"
echo.
findstr /I /R "^https://.*trycloudflare\.com/monitor$" "PHONE_PUBLIC_URL.txt" >nul 2>&1
if errorlevel 1 (echo XATO: haqiqiy public URL hali yaratilmagan.) else (echo OK: public URL topildi.)
:END
pause
