@echo off
setlocal EnableExtensions EnableDelayedExpansion
cd /d "%~dp0"
set "PORT=5000"
set "PROXYPORT=5001"
set "CF=%~dp0cloudflared.exe"
set "LOG=%~dp0cloudflared_phone.log"
set "URLFILE=%~dp0PHONE_PUBLIC_URL.txt"

echo ============================================================
echo MAMURIYAT - TELEFON UCHUN HTTPS MONITOR
 echo Administrator huquqi KERAK EMAS
echo ============================================================

if not exist "%CF%" (
  echo XATO: cloudflared.exe topilmadi.
  pause
  exit /b 1
)

for /f "tokens=5" %%P in ('netstat -ano ^| findstr ":%PORT%" ^| findstr LISTENING') do taskkill /PID %%P /T /F >nul 2>&1
for /f "tokens=5" %%P in ('netstat -ano ^| findstr ":%PROXYPORT%" ^| findstr LISTENING') do taskkill /PID %%P /T /F >nul 2>&1
powershell -NoProfile -ExecutionPolicy Bypass -Command "$ps=Get-CimInstance Win32_Process -Filter 'Name = ''cloudflared.exe'''; foreach($p in $ps){try{Stop-Process -Id $p.ProcessId -Force -ErrorAction SilentlyContinue}catch{}}" >nul 2>&1

if exist "%LOG%" del /q "%LOG%" >nul 2>&1
if exist "%URLFILE%" del /q "%URLFILE%" >nul 2>&1

start "MAMURIYAT SERVER" /min cmd /c "cd /d ""%~dp0"" && py -3 server.py"
for /l %%N in (1,1,15) do (
  curl -fsS --max-time 2 http://127.0.0.1:%PORT%/api/health >nul 2>&1
  if not errorlevel 1 goto SERVER_OK
  timeout /t 1 /nobreak >nul
)
echo XATO: server ishga tushmadi.
pause
exit /b 1

:SERVER_OK
start "MAMURIYAT PUBLIC PROXY" /min cmd /c "cd /d ""%~dp0"" && py -3 public_monitor_proxy.py"
for /l %%N in (1,1,15) do (
  curl -fsS --max-time 2 http://127.0.0.1:%PROXYPORT%/monitor >nul 2>&1
  if not errorlevel 1 goto PROXY_OK
  timeout /t 1 /nobreak >nul
)
echo XATO: proxy ishga tushmadi.
pause
exit /b 1

:PROXY_OK
start "MAMURIYAT PHONE TUNNEL" /min cmd /c "cd /d ""%~dp0"" && cloudflared.exe tunnel --no-autoupdate --url http://127.0.0.1:%PROXYPORT% > ""%LOG%"" 2>&1"
set "PUBLIC="
for /l %%N in (1,1,45) do (
  timeout /t 1 /nobreak >nul
  for /f "tokens=5" %%U in ('findstr /R /C:"https://.*trycloudflare.com" "%LOG%" 2^>nul') do if not defined PUBLIC set "PUBLIC=%%U"
  if defined PUBLIC goto GOT
)
echo XATO: HTTPS manzil olinmadi.
echo cloudflared_phone.log faylini tekshiring.
pause
exit /b 1

:GOT
>"%URLFILE%" echo %PUBLIC%/monitor
start "PHONE URL" notepad.exe "%URLFILE%"
echo.
echo TELEFON UCHUN MANZIL:
echo %PUBLIC%/monitor
echo.
echo Administrator huquqi kerak emas.
endlocal
exit /b 0
