@echo off
start "" "http://10.142.29.9:5000/admin"
