@echo off
setlocal
cd /d "%~dp0"
set "IP="
for /f "delims=" %%I in ('powershell -NoProfile -Command "$r=Get-NetRoute -AddressFamily IPv4 -DestinationPrefix ''0.0.0.0/0'' -ErrorAction SilentlyContinue ^| Sort-Object RouteMetric ^| Select-Object -First 1; if($r){$a=Get-NetIPAddress -AddressFamily IPv4 -InterfaceIndex $r.ifIndex -ErrorAction SilentlyContinue ^| Where-Object {$_.IPAddress -notlike ''127.*'' -and $_.IPAddress -notlike ''169.254.*''} ^| Select-Object -First 1 -ExpandProperty IPAddress; if($a){$a}}"') do set "IP=%%I"
if not defined IP set "IP=127.0.0.1"
start "MAMURIYAT MONITOR" "http://%IP%:5000/monitor?mode=monitor&design=2"
echo Monitor: http://%IP%:5000/monitor?mode=monitor^&design=2
pause
endlocal
