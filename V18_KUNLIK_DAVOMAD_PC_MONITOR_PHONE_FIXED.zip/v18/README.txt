MAMURIYAT LIVE MONITOR V10.4 — WIFI/LAN NO ADMIN

START_ALL.bat oddiy foydalanuvchi huquqida ishlaydi.
Dastur administrator oynasini chaqirmaydi va tizim xavfsizlik sozlamalarini o'zgartirmaydi.

Server: 0.0.0.0:5000
Admin: http://KOMPYUTER_IP:5000/admin
Monitor: http://KOMPYUTER_IP:5000/monitor

START_ALL.bat kompyuterning faol LAN/Wi-Fi IPv4 manzilini avtomatik topadi.
Telefon shu Monitor manzilidan foydalanadi.
Telefon va kompyuter bir xil Wi-Fi/LAN tarmog'ida bo'lishi shart.
Telefon uchun 127.0.0.1 yoki HTTPS ishlatilmaydi.

Agar kompyuterda ochilib, telefonda ochilmasa, tizim xavfsizlik devori yoki
routerdagi AP/Client Isolation/Guest Wi-Fi sabab bo'lishi mumkin.
