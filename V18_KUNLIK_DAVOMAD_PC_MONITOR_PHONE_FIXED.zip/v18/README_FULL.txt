V17 FIX: START_ALL server launcher corrected.

MAMURIYAT BO'LIMI — ONLINE FINAL DASHBOARD

ASOSIY KO'RINISH
Dashboard_Admin_Responsive_FIXED17.html asosidagi ko'rinish saqlandi.
admin.html va index.html shu dashboardning ishga tayyor nusxalari.

ZIP ICHIDAGI MA'LUMOTLAR
- data.json — 2203 ta xodim yozuvi va barcha mavjud oylar bo'yicha snapshot.
- Dashboard_BAZA.xlsm — original Excel baza.
- Dashboard_Admin_Responsive_FIXED17.html — tasdiqlangan dashboard ko'rinishi.
- admin.html / index.html — ishga tushirish uchun nusxalar.
- monitor.html — monitor ko'rinishi.
- google_apps_script/Code.gs — Google Sheets proxy uchun.
- server.py — LAN/monitor/admin serveri.
- START_ALL.bat — serverni ishga tushirish.

MUHIM
Manbada ma'lumot mavjud bo'lgan oylar: Yanvar, Fevral, Mart, Aprel, May, Iyun, Iyul.
Avgust–Dekabr uchun source snapshotda yozuv bo'lmasa, dashboard ularni o'zi to'qib chiqarmaydi.

ISHLASH LOGIKASI
- Bo'lim tanlash ishlaydi.
- Kun tanlash ishlaydi.
- Yo'qlar/Ishdagilar ro'yxati tanlangan bo'lim va smena bo'yicha qayta filtrlanadi.
- Ish soatlari oynasida Sverh = 0 bo'lgan xodimlar ham ko'rsatiladi.
- Ish soatlari jadvali Jami soatlar bo'yicha katta qiymatdan kichikka boshlanadi.
- Har bir ustun bo'yicha filter/sort mavjud.
- Smena kesimida alohida xodimlar ro'yxati ochiladi.
- Orqaga tugmasi ochilgan sahifaga qaytaradi.
- 32" monitor/TV va telefon uchun responsive CSS saqlangan.

ISHGA TUSHIRISH
1. START_ALL.bat ni ishga tushiring.
2. Kompyuterda /admin yoki /monitor ochiladi.
3. Telefon/TV bir xil Wi-Fi/LAN tarmog'ida bo'lsa:
   http://KOMPYUTER_IP:5000/monitor

GOOGLE SHEETS
Google Sheet Viewer qilib ulashilgan bo'lishi kerak.
Private Sheet uchun google_apps_script/Code.gs ni Apps Script Web App sifatida deploy qilib,
Google Apps Script sozlash shart emas; server Google Sheets XLSX exportini to‘g‘ridan-to‘g‘ri oladi. google_proxy.json faqat eski Apps Script moslik rejimi uchun.


MUHIM V17:
- START_ALL server.py ni Python executable bilan to'g'ridan-to'g'ri ishga tushiradi.
- Agar server ishga tushmasa, server_start.log ko'rsatiladi.
- Kompyuterning o'zida Admin va Monitor avtomatik ochiladi.
- Boshqa TV/telefon uchun LAN manzil LAN_URLS.txt ichida.
- Boshqa Wi-Fi/4G uchun PHONE_PUBLIC_URL.txt ichidagi HTTPS manzil ishlatiladi.
