@echo off
echo Bu versiyada Firewall qoidasi qo'shilmaydi.
echo Telefon uchun START_ALL.bat yoki START_PHONE_FIXED.bat dan foydalaning.
pause
