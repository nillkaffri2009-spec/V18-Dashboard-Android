V18 — ASOSIY DESIGN 2 FINAL
1) START_ALL.bat ni bosing.
2) PC admin: http://127.0.0.1:5000/admin
3) Monitor: kompyuter LAN IP:5000/monitor
4) Telefon: kompyuter LAN IP:5000/phone
5) Kunlik davomad asosiy ekran. Ish soatlari va KPI alohida.
6) Google Sheets LIVE birinchi manba; ulanish bo'lmasa Dashboard_BAZA zaxira ma'lumoti ishlaydi.
7) Monitor faqat ko'rish. Telefon boshqaruvni olsa monitor telefon holatini ko'rsatadi; telefon uzilsa boshqaruv kompyuterga qaytadi.
