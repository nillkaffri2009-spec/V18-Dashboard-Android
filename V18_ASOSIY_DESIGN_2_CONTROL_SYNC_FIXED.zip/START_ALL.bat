@echo off
cd /d "%~dp0"
start "V18 Server" python server.py
timeout /t 2 /nobreak >nul
start "" http://127.0.0.1:5000/admin
start "" http://127.0.0.1:5000/monitor
