from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from pathlib import Path
from urllib.parse import urlparse
import json, time, socket, threading
ROOT=Path(__file__).resolve().parent
lock=threading.Lock()
state={'source':'computer','epoch':1,'revision':1,'updatedAt':int(time.time()*1000),'devices':{'computer':{'owner':'','view':None},'phone':{'owner':'','view':None},'monitor':{'owner':'','view':None}},'phoneUntil':0}
def default_view(): return {'month':0,'day':1,'page':1,'department':'','shift':'','hours':'','detail':'','query':'','tableShift':'','tableStatus':'','minHours':'','maxHours':''}
def expire():
    global state
    if state['source']=='phone' and state.get('phoneUntil',0)<int(time.time()*1000):
        state['source']='computer'; state['epoch']+=1; state['revision']+=1

def public(role,cid):
    expire(); src=state['source']; v=state['devices'].get(src,{}).get('view') or default_view()
    owner=state['devices'].get(role,{}).get('owner','')
    return {'source':src,'epoch':state['epoch'],'revision':state['revision'],'updatedAt':state['updatedAt'],'view':v,'active':src==role and owner==cid,'isController':src==role and owner==cid}
def ip():
    try:
        s=socket.socket(socket.AF_INET,socket.SOCK_DGRAM); s.connect(('8.8.8.8',80)); a=s.getsockname()[0]; s.close(); return a
    except:return '127.0.0.1'
class H(SimpleHTTPRequestHandler):
    def __init__(self,*a,**k): super().__init__(*a,directory=str(ROOT),**k)
    def log_message(self,*a): pass
    def end_headers(self): self.send_header('Cache-Control','no-store'); super().end_headers()
    def js(self,o,c=200):
        b=json.dumps(o,ensure_ascii=False).encode(); self.send_response(c); self.send_header('Content-Type','application/json; charset=utf-8'); self.send_header('Content-Length',str(len(b))); self.end_headers(); self.wfile.write(b)
    def ids(self): return self.headers.get('X-Dashboard-Role','computer'),self.headers.get('X-Dashboard-Device','')
    def do_GET(self):
        p=urlparse(self.path).path
        if p in ['/','/admin','/monitor','/phone','/tv']: self.path='/index.html'; return super().do_GET()
        if p=='/api/data':
            try:self.js(json.loads((ROOT/'data.json').read_text(encoding='utf-8')))
            except Exception as e:self.js({'error':str(e)},500)
            return
        if p=='/api/state':
            role,cid=self.ids()
            with lock:self.js(public(role,cid))
            return
        if p=='/api/health': return self.js({'ok':True,'ip':ip(),'port':5000})
        return super().do_GET()
    def do_POST(self):
        if urlparse(self.path).path!='/api/state': return self.send_error(404)
        role,cid=self.ids(); n=int(self.headers.get('Content-Length','0')); body=json.loads(self.rfile.read(n) or b'{}'); now=int(time.time()*1000)
        with lock:
            expire(); act=body.get('action')
            if act=='claim' and role!='monitor':
                state['source']=role; state['devices'][role]['owner']=cid; state['epoch']+=1; state['revision']+=1; state['updatedAt']=now; state['phoneUntil']=now+25000 if role=='phone' else 0
            else:
                if state['source']!=role or state['devices'][role].get('owner')!=cid or body.get('epoch')!=state['epoch']: return self.js({'error':'Boshqaruv boshqa qurilmada. Holat yangilanadi.'},409)
                if act=='update': state['devices'][role]['view']=body.get('view'); state['revision']+=1; state['updatedAt']=now
                elif act=='heartbeat' and role=='phone': state['phoneUntil']=now+25000
                elif act=='release' and role=='phone': state['source']='computer'; state['epoch']+=1; state['revision']+=1; state['phoneUntil']=0; state['updatedAt']=now
            self.js(public(role,cid))
if __name__=='__main__':
    a=ip(); print('ADMIN  : http://127.0.0.1:5000/admin'); print('MONITOR:',f'http://{a}:5000/monitor'); print('PHONE  :',f'http://{a}:5000/phone'); ThreadingHTTPServer(('0.0.0.0',5000),H).serve_forever()
